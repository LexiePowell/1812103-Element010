//**************************************//
//* StudentID: 1812103                  //
//* Date: 25.07.2020                    //
//* Task: 1b                            //
//* Description: 3 integer Calculator   //
//**************************************//

//importing the java.util API to be able to use the util.Scanner
import java.util.Scanner;

public class Task1b {
		//using the Scanner from the java library
		//initialising and declaring the class instance fields
		//this class is public, therefore allowing it to be accessed by objects, classes and packages
		private static int numberOne = 0;
		private static int numberTwo = 0;
		private static int numberThree = 0;
		private static double average = 0;
		
		//declaring the object input of class Scanner
		private static Scanner input;
		
			public static void main(String[] args) {
			//using the scanner class to achieve user input
			//this will be stored in the Scanner input object
			Scanner input = new Scanner(System.in);
		
				//asking the user to input the first integer from the memory location in input
				System.out.println("Please input your first number: ");
				int numberOne = input .nextInt();
				//asking the user for the second integer from the input location
				System.out.println("Please input your second number: ");
				int numberTwo = input .nextInt();
				//asking the user for the third integer
				System.out.println("Please input your third number: ");
				int numberThree = input .nextInt();
		
		
				/*using less than and more than operators to figure out the order of all the integers, and the order they are printed
				 whether they are first, second or third. This is done with if, else if conditional statements to figure out which 
				are the largest and the smallest integers when they are entered by the user*/
				//when the statements have organised the integers into the correct descending order, the system prints them using Println
				if ((numberOne > numberTwo && numberOne > numberThree) & (numberTwo > numberThree))
				{	
				System.out.println("The correct decsending order is: " + numberOne + ", " + numberTwo + ", " + numberThree);
				}
				else if ((numberOne > numberTwo && numberOne > numberThree) & (numberThree > numberTwo))
				{
				System.out.println("The correct descending order is: " + numberOne + ", " + numberThree + ", " + numberTwo);
				} 
				else if ((numberTwo > numberOne && numberTwo > numberThree) & (numberOne > numberThree))
				{
				System.out.println("The correct descending order is: " + numberTwo + ", " + numberOne + ", " + numberThree);
				}
				else if ((numberTwo > numberOne && numberTwo > numberThree) & (numberThree > numberOne))
				{
				System.out.println("The correct descending order is: " + numberTwo + ", " + numberThree + ", " + numberOne);
				}
				else if ((numberThree > numberOne && numberThree > numberTwo) & (numberOne > numberTwo))
				{
				System.out.println("The correct descending order is:" + numberThree + ", " + numberOne + ", " + numberTwo);
				}
				else if ((numberThree > numberOne && numberThree > numberTwo) & (numberTwo > numberOne))
				{
				System.out.println("The correct descending order is: " + numberThree + ", " + numberTwo + ", " + numberOne);
				}
				/*if the integers were enterd incorrectly or they were of the same value, the system outputs an invalid message to the user*/
				else 
				{
				System.out.println("Numbers are all equal or invalid entry");
				}
		
				//since there are 3 integers, you can achieve the average by using the divison operator
				average = (numberOne + numberTwo + numberThree) / 3;
		
					//The system prints the averages to the user by using println
				System.out.println("The average of these numbers added together is " + average); 
		}// end method
}// end class