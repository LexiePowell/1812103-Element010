//*******************************//
//* StudentID: 1812103           //
//* Date: 31.03.2020             //
//* Task: 1a                     //
//* Description: 2 integer Calc  //
//*******************************//
package Task1a;

import java.util.Scanner;

public class Task1a {

	public static void main(String[] args) {
	Scanner input = new Scanner(System.in);
	
	//The system will ask the user to input two numbers//
	System.out.println("Enter a number: ");
	int a = input.nextInt();
	
	System.out.println("Enter a number: ");
	int b = input.nextInt();
	
	//The system will compute the sum and display it//
	int newNumber = a + b;
	System.out.println("The new number is: ");
	System.out.println(newNumber);
	}
}
