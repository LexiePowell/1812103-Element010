//*************************************//
//* StudentID: 1812103                 //
//* Date: 23.07.2020                   //
//* Task: 1a                           //
//* Description: Testing the basic     //
//* primitives and operations of Java  //
//*************************************//
package Task1a;
//importing the java.util package so I can use the util.Scanner
import java.util.Scanner;

public class Task1a {

	//Declaring and explicitly initialising the class instance fields
	private static int numberOne = 0; 
	private static int numberTwo = 0;
	private static int muxRes = 0;
	
	/*the main method is used to execute the program and since it is public,
	it allows for global visability. It also does not need to instantiate
	an object to have a reference*/
	public static void main(String[] args) 
	{
	//the scanner method allows you to store the users input into the MyInput variable 
	Scanner input = new Scanner(System.in);
	//asking the user for input through the println command which prints in java
	//getting the first integer inputted from memory location by the user
	System.out.println("Enter a number: ");
	numberOne = input.nextInt();
	//getting the second integer from the users memory location
	//using println to print the line in java
	System.out.println("Enter a number: ");
	numberTwo = input.nextInt();
	
	//The system will multiply the two integers together using the multiplication
	// operator and storing it within the muxRes variable
	muxRes = numberOne * numberTwo;
	
	//Display the multiplication result of numberOne and numberTwo to the user
	System.out.println("The new number is: ");
	System.out.println(muxRes);
	}
}
