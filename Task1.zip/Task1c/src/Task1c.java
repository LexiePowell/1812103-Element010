//*******************************//
//* StudentID: 1812103           //
//* Date: 31.03.2020             //
//* Task: 1c                     //
//* Description: Paired Sum Calc //
//*******************************//

import java.util.Scanner;

public class Task1c {

	public static void main(String[] args) {
	Scanner input = new Scanner(System.in);
	
	//The system asks the user to input 10 integers//
	System.out.println("Enter the 1st number: ");
	int a = input.nextInt();
	
	System.out.println("Enter the 2nd number: ");
	int b = input.nextInt();
	
	System.out.println("Enter the 3rd number: ");
	int c = input.nextInt();
	
	System.out.println("Enter the 4th number: ");
	int d = input.nextInt();
	
	System.out.println("Enter the 5th number: ");
	int e = input.nextInt();
	
	System.out.println("Enter the 6th number: ");
	int f = input.nextInt();
	
	System.out.println("Enter the 7th number: ");
	int g = input.nextInt();
	
	System.out.println("Enter the 8th number: ");
	int h = input.nextInt();
	
	System.out.println("Enter the 9th number: ");
	int i = input.nextInt();
	
	System.out.println("Enter the 10th number: ");
	int j = input.nextInt();
	
	//The system then computes the paired sums and displays them as a new number//
	int newNumber1 = a + b;
	System.out.println("The new paired number is: ");
	System.out.println(newNumber1);
	
	int newNumber2 = b + c;
	System.out.println("The new paired number is: ");
	System.out.println(newNumber2);
	
	int newNumber3 = c + d;
	System.out.println("The new paired number is: ");
	System.out.println(newNumber3);
	
	int newNumber4 = d + e;
	System.out.println("The new paired number is: ");
	System.out.println(newNumber4);
	
	int newNumber5 = e + f;
	System.out.println("The new paired number is: ");
	System.out.println(newNumber5);
	
	int newNumber6 = f + g;
	System.out.println("The new paired number is: ");
	System.out.println(newNumber6);
	
	int newNumber7 = g + h;
	System.out.println("The new paired number is: ");
	System.out.println(newNumber7);
	
	int newNumber8 = h + i;
	System.out.println("The new paired number is: ");
	System.out.println(newNumber8);
	
	int newNumber9 = i + j;
	System.out.println("The new paired number is: ");
	System.out.println(newNumber9);
	
	}
}