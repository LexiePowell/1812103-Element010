//********************************//
//* StudentID: 1812103            //
//* Date: 04.04.2020              //
//* Task: 1c Part 2               //
//* Description: Average of 3 Ints//
//********************************//

import java.util.Scanner; 

public class Task1cpart2 {

	public static void main(String[] args) {
		
		public class Task1cpart2 {
			private static int first = 0;
			private static int second = 0;
			private static int third = 0;
			private static int temp = 0;
			private static int sum = 0;
			
			
		public static void main(String[] args) {
			Scanner input = new Scanner(System.in);
			
			//The system asks the user to input three integers//
			System.out.println("Please input your first number: ");
			int first = input .nextInt();
			System.out.println("The entered first integer is: " + first);
			
			System.out.println("Please input your second number: ");
			int second = input .nextInt();
			System.out.println("The entered second integer is: " + second);
			
			System.out.println("Please input your third number: ");
			int third = input .nextInt();
			System.out.println("The entered third integer is: " + third);
			
			//The system then computes the sum of the three integers//
			sum = first + second + third; 
			System.out.println("The sum of the integers entered is: " + sum);
			
			//The system then computes the order of the three integers//
			if (first > second) {
				temp = first;
				first = second;
				second = temp;
			} 
			if (second > third) {
				temp = third;
				third = second;
				second = temp;
			}
			if (first > second) {
				temp = first;
				third = second;
				second = temp;
			}
			
			//The system displays the integers in order to the user//
			System.out.println("The number in order are: " + first + ", " + second + ", " + third);
			
			//The system then computes the averages of the three integers//
			int average = first + second + third / 3;
			
			//The system displays the averages to the user//
			System.out.println("The average of these numbers added together is " + average); 
		}
	}
	}
}