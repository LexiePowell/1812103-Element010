//*************************************//
//* StudentID: 1812103                 //
//* Date: 29.07.2020                   //
//* Task: 2a                           //
//* Description: PrintAccount.java      //
//*                                    //
//*************************************//

/*there is no main method for this class since it is ran from PrintAccountTest. This is because
its main responsibility is storing the methods for an object when then are initialised  */
public class PrintAccount
{

	//declare the class instance fields
	public String name;
	public double balance;
	
	public String getName()
	{
	//this returns the set name to the object
		return name;
	}
	
	public void setName(String name) 
	{
	//this is used to set the name of the String name
	//the String name is this.name and "name" is the name within the method
		this.name = name;
	}
	//public PrintAccount constructor and is used to construct objects when 
	//they are created in another class
	public PrintAccount(double balance)
	{
		if (balance >= 0.0)
		{
			this.balance = balance;
		}
		//in case of an incorrect balance, the system will display the invalid output 
		//using println to the user
		else
		{
			System.out.println("Invalid balance");
		}
	}
	//using a public void will not return the value
	public void payIn(double amount) 
	{
		//adds the amount paid into the account onto the original balance
		balance = balance + amount;
	}
	//gets the balance of the double balance variable and then will return it
	public double getBalance() 
	{
		//after the method is used, the balance is returned
		return balance;
	}
}