//*************************************//
//* StudentID: 1812103                 //
//* Date: 29.07.2020                   //
//* Task: 2a                           //
//* Description: PrintAccountTest.java //
//*                                    //
//*************************************//
import java.util.Scanner;

public class PrintAccountTest
//this is the main method that is used to implement the java program
{
	public static void main(String[] args) 
	{
		/*creating User 1 from PrintAccount.java and setting a specific set
		balance from constructor*/
		PrintAccount UserOne = new PrintAccount(0.00);
		//using the payIn method previously used in PrintAccount.java to minus 
		//120.00 from object User 1 
		UserOne.payIn(27.00);
		//this uses the setter from PrintAccount object and sets the default name to User 1
		UserOne.setName(" ");
		//creating a new object for User 2 with a set balance from the PrintAccount constructor
		PrintAccount UserTwo = new PrintAccount(0.00);
		//using the payIn method to minus 120.00 from object User 2
		UserTwo.payIn(-120.00);
		//setting the default name to User 2 using the method setName from PrintAccount
		UserTwo.setName(" ");
		//asking for user input by using the getName method for User 1
		System.out.printf(UserOne.getName() + "Enter name of User 1: ");
		//using Scanner class to achieve user input
		Scanner userInput = new Scanner(System.in);
		//setting User 1 as the next memory location in input variable
		UserOne.setName(userInput.nextLine());
		//prints the users name and balance
		System.out.printf(UserOne.getName() + " has a balance of " + UserOne.getBalance());
		//setting the next input variable onto the next line, the user will have to press enter to continue
		UserTwo.setName(userInput.nextLine());
		//getting the name of User 2 with the getName method
		System.out.printf(UserTwo.getName() + "Enter name of User 2: ");
		//sets the name of User 2 using setName method and sets next memory location
		UserTwo.setName(userInput.nextLine());
		//closing the scanner
		userInput.close();
		//prints users name and balance
		System.out.printf(UserTwo.getName() + " has a balance of " + UserTwo.getBalance());
	}
}