//**************************************//
//* StudentID: 1812103                  //
//* Date: 06.08.2020                    //
//* Task: 2b                            //
//* Description: PrintAccountTest2.java //
//*                                     //
//**************************************//

//importing and declaring the javax.swing package
import javax.swing.*;

public class PrintAccountTest2 {
	//declaring the string types and the class instance fields
	public static String BalanceOne, BalanceTwo;
	public static double OneTransaction, TwoTransaction, tempTwo, tempOne;
	public static String NameOne, NameTwo;

	//the main method
	public static void main(String[] args) {
		//creating three JFrames from the API to be objects
		JFrame frameOne = new JFrame("what is the name of customer 1?:");
		JFrame frameTwo = new JFrame("what is the balance of customer 1?:");
		JFrame frameThree = new JFrame("what is the name of customer 2?:");
		//obtaining the input from the customer and storing it within the variable NameOne
		NameOne = JOptionPane.showInputDialog(frameOne, "name of customer 1:");
		
		BalanceOne = JOptionPane.showInputDialog(frameTwo, "What is " + NameOne + " current balance?:");
		
		//obtaining the input from customer 2 and storing it as NameTwo 
		NameTwo = JOptionPane.showInputDialog(frameOne, "what is the name of customer 2?");
		
		BalanceTwo = JOptionPane.showInputDialog(frameTwo, "What is " + NameTwo + " current balance?:");
		
		//creating an object for customer 1 and 2 and obtaining the inputs
		//parsing the amounts with the constructor method
		PrintAccount2 custOne = new PrintAccount2(Double.parseDouble(BalanceOne), NameOne);
		PrintAccount2 custTwo = new PrintAccount2(Double.parseDouble(BalanceOne), NameTwo);
		//asking customers how much they would like to pay in through making a fourth JFrame
		JFrame frameFour = new JFrame("Hi" + custTwo.getName());
		
		//obtaining customer input and storing it within the string variable
		String tempFour = String.valueOf(OneTransaction);
		
		//asking for customer input and transaction being read from payIn method
		tempFour = JOptionPane.showInputDialog(frameThree,
				"what is the amount you would like to pay in , " + custOne.getName());
		
		tempOne = Double.parseDouble(tempFour);

		String tempThree = String.valueOf(TwoTransaction);
		
		
		tempThree = JOptionPane.showInputDialog(frameFour,
				"what is the amount you would like to pay in , " + custTwo.getName());
		tempTwo = Double.parseDouble(tempThree);
		
		//customers use payIn method to complete transaction to accounts 
		custOne.payIn(tempOne);
		custTwo.payIn(tempTwo);
		
		//displaying the users names and balances in double and string instance fields
		JOptionPane.showMessageDialog(null, custOne.getName() + "balance is " + custOne.getBalance());
		JOptionPane.showMessageDialog(null, custTwo.getName() + "balance is " + custTwo.getBalance());
	}
}