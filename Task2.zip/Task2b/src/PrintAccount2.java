//*************************************//
//* StudentID: 1812103                 //
//* Date: 06.08.2020                   //
//* Task: 2b                           //
//* Description: PrintAccount2.java    //
//*                                    //
//*************************************//

public class PrintAccount2 {

		//declaring and initiating variables
		public String name;
		public double balance;
		
		//getName method
		public String getName()
		{
			//returns the name and object
			return name;
		}
		
		//setting the name method from the variable string
		public void setName(String name)
		{
			this.name = name;
		}
		//create PrintAccount object with name and balance through using a constructor
		public PrintAccount2(double balance , String name) 
		{
			this.name = name;
			if (balance >= 0.0)
			{
				this.balance = balance;
			}
			//if balance is invalid or incorrect, an invalid message will appear to the user
			//through the use of println
			else 
			{
				System.out.println("Invalid balance");
			}
		}
		//does not return the value since it is a public void
		public void payIn(double amount) 
		{
			balance = balance + amount;
		}
		//returns the balance once it obtains the double balance variable
		public double getBalance() 
		{
			return balance;
		}
	}
