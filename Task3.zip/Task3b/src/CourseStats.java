//*************************************//
//* StudentID: 1812103                 //
//* Date: 06.08.2020                   //
//* Task: 3b                           //
//* Description: CourseStats.java      //
//*                                    //
//*************************************//

//importing and declaring the javax swing packages
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class CourseStats {
	//declaring and initialising the integers for student passes, 
	//failures and overall grade amount
	public static int passes = 0;
	public static int failures = 0;
	public static int overallGrade;
	//initialising a string type for message
	public static String message = " ";
	
	//the main method
	public static void main(String[] args) 
	{
		//initialising the student counter for while loop
		int studentCounter = 1;
	//creating a new JFrame object from the javax package
	JFrame frame = new JFrame();
		
	//if the student counter is less than or equal to 40, use parse string from the input
	while (studentCounter <= 40) 
	{
		//Getting user input for student's grade
		overallGrade = Integer
				.parseInt(JOptionPane.showInputDialog(frame, "Enter Student" + studentCounter + "'s " + "Grade"));
			
	//if the grade is equal to 1, then 1 is added to the passes amount	
	if (overallGrade == 1) 
		{
		passes++;
		}
	//if the grade is equal to 0, then 0 is added to the failures amount	
	else if (overallGrade ==0) 
		{
		failures++;
		}
	//the studentCounter will loop again once the grade from each student is added
	studentCounter++;
		
	}
		//if there are more than 32 students that have passed
	if (passes > 32) 
		{
		//the system will output a message to the tutors
		message = ("Congratulations to the Tutors!");
		}
	//JOptionPane is used to show the message containing the number of passes and failures	
	JOptionPane.showMessageDialog(frame, "The number of passes within the class was: " + passes + "\n" + "The number of failures within"
				+ " the class was: " + failures + "\n" + message);
	}
}