//*************************************//
//* StudentID: 1812103                 //
//* Date: 06.08.2020                   //
//* Task: 3a                           //
//* Description: CourseStats.java      //
//*                                    //
//*************************************//

import java.util.Scanner;

public class CourseStats {
	//declaring and initialising the integers for student passes, 
	//failures and overall grade amount
	public static int passes = 0;
	public static int failures = 0;
	public static int overallGrade;
	
	private static Scanner scan;
	
	public static void main(String[] args) {
		//initialising the student counter for while loop
		int studentCounter = 1;
		
		scan = new Scanner(System.in);
		//loop until the student counter is less than or equal to 40
		while (studentCounter <= 40) {
			//Getting user input for student's grade
			System.out.println("Enter Student" + studentCounter + "'s " + "Grade");
			//getting user input as the integer
			overallGrade = scan.nextInt();
		//if the grade is equal to 1, then 1 is added to the passes amount	
		if (overallGrade == 1) {
			passes++;
			}
		//if the grade is equal to 0, then 0 is added to the failures amount	
		else if (overallGrade ==0) {
			failures++;
			}
		//the studentCounter will loop again once the grade from each student is added
		studentCounter++;
		
		}
	scan.close();
	//the system outputs the number of passes while using println
		
	System.out.println("The number of passes within the class was: " + passes);
	//the system outputs the number of failures while using println
	System.out.println("The number of failures within the class was: " + failures);
	
		//if passes are more than 32
		if (passes > 32) {
			//the system will output a message to the tutors
			System.out.println("Congratulations to the Tutors!");
	}
		}
}